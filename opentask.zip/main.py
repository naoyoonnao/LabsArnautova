import tkinter as tk
from tkinter import messagebox, filedialog
import json
import pygame

class MusicPlayer:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple Music Player")
        self.root.geometry("400x300")

        # Initialize pygame mixer
        pygame.mixer.init()

        # Playlist variables
        self.playlist = []
        self.current_track_index = 0

        # Create UI components
        self.create_ui()

        # Load initial playlist
        self.load_playlist()

    def create_ui(self):
        # Track Information Label
        self.track_label = tk.Label(
            self.root, 
            text="No Track Selected", 
            font=("Arial", 12)
        )
        self.track_label.pack(pady=20)

        # Control Buttons Frame
        control_frame = tk.Frame(self.root)
        control_frame.pack(pady=10)

        # Previous Button
        prev_button = tk.Button(
            control_frame, 
            text="◀ Previous", 
            command=self.play_previous
        )
        prev_button.pack(side=tk.LEFT, padx=10)

        # Play Button
        self.play_button = tk.Button(
            control_frame, 
            text="▶ Play", 
            command=self.toggle_play
        )
        self.play_button.pack(side=tk.LEFT, padx=10)

        # Next Button
        next_button = tk.Button(
            control_frame, 
            text="Next ▶", 
            command=self.play_next
        )
        next_button.pack(side=tk.LEFT, padx=10)

        # Playlist Load Button
        load_button = tk.Button(
            self.root, 
            text="Load Playlist", 
            command=self.load_playlist_from_file
        )
        load_button.pack(pady=10)

    def load_playlist(self, filename='playlist.json'):
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                self.playlist = json.load(f)
            
            if not self.playlist:
                messagebox.showwarning("Warning", "Playlist is empty!")
                return

            self.current_track_index = 0
            self.update_track_label()

        except FileNotFoundError:
            messagebox.showerror("Error", f"Playlist file {filename} not found!")
        except json.JSONDecodeError:
            messagebox.showerror("Error", "Invalid JSON format in playlist!")

    def load_playlist_from_file(self):
        filename = filedialog.askopenfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")]
        )
        if filename:
            self.load_playlist(filename)

    def update_track_label(self):
        if self.playlist:
            current_track = self.playlist[self.current_track_index]
            self.track_label.config(
                text=f"{current_track['title']} - {current_track['artist']}"
            )

    def toggle_play(self):
        if not self.playlist:
            messagebox.showwarning("Warning", "No playlist loaded!")
            return

        current_track = self.playlist[self.current_track_index]
        
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.pause()
            self.play_button.config(text="▶ Play")
        else:
            try:
                pygame.mixer.music.load(current_track['file'])
                pygame.mixer.music.play()
                self.play_button.config(text="❚❚ Pause")
            except Exception as e:
                messagebox.showerror("Error", f"Cannot play track: {str(e)}")

    def play_next(self):
        if not self.playlist:
            return
        
        self.current_track_index = (self.current_track_index + 1) % len(self.playlist)
        pygame.mixer.music.stop()
        self.update_track_label()
        self.play_button.config(text="▶ Play")

    def play_previous(self):
        if not self.playlist:
            return
        
        self.current_track_index = (self.current_track_index - 1) % len(self.playlist)
        pygame.mixer.music.stop()
        self.update_track_label()
        self.play_button.config(text="▶ Play")

def main():
    root = tk.Tk()
    player = MusicPlayer(root)
    root.mainloop()

if __name__ == "__main__":
    main()